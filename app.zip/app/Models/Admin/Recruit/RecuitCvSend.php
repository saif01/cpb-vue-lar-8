<?php

namespace App\Models\Admin\Recruit;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class RecuitCvSend extends Model
{
    use HasFactory;

    protected $guarded = [];
}
