<template>
    <div>
        <h1>You have no admin access</h1>
    </div>
</template>