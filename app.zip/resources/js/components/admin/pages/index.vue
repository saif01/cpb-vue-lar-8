<template>
   <div>

        <h1 class="bg-info">Admin Dashboard</h1>

        <!-- <b-card no-body>
            <div class="bg-secondary text-light">
            This is some content without the default section. Notice the
            lack of padding between the card's border and this gray 
            </div>
        </b-card> -->
   </div>
</template>
