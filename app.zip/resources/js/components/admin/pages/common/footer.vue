<template>
    <div>
        <footer class="footer">
            <div class="container">
                <div class="text-center">
                    <span> &copy; Copyright <strong><span>CPB-IT</span></strong> </span>
                </div>
            </div>
        </footer>
    </div>
</template>

