<template>
   <div>
        <section class="map mt-2" data-aos="zoom-in-down">
            <div class="container-fluid p-0">
                <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3643.600262688122!2d90.24400221435431!3d24.045157483370307!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3755e6cba58c5335%3A0x1b52ffdcf921b2a0!2sC.P.+Bangladesh+Head+Office+%26+Dhaka+Feed+Mill!5e0!3m2!1sen!2sbd!4v1560325967397!5m2!1sen!2sbd"
                    frameborder="0" style="border:0;" allowfullscreen=""></iframe>
            </div>
        </section>
   </div>
</template>